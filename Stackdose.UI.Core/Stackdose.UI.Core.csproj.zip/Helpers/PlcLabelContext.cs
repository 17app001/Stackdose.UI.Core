using System;
using System.Windows;
using Stackdose.UI.Core.Controls;
using System.Collections.Generic;
using System.Linq;

namespace Stackdose.UI.Core.Helpers
{
    /// <summary>
    /// PlcLabel �W�U��޲z (PlcLabel Context Manager)
    /// �γ~�G�Τ@�޲z�Ҧ� PlcLabel �����ܧ�ƥ�A���� SensorContext
    /// </summary>
    public static class PlcLabelContext
    {
        #region �R�A�ݩ�

        /// <summary>
        /// �w���U�� PlcLabel �M��]�Ω�۰ʺʱ��^
        /// </summary>
        private static readonly HashSet<WeakReference<PlcLabel>> _registeredLabels = new HashSet<WeakReference<PlcLabel>>();
        private static readonly object _lock = new object();

        #endregion

        #region �ƥ�w�q

        /// <summary>
        /// PlcLabel ���ܧ�ƥ� (������ PlcLabel �����ܧ��Ĳ�o)
        /// </summary>
        public static event EventHandler<PlcLabelValueChangedEventArgs>? ValueChanged;

        #endregion

        #region ���U�޲z

        /// <summary>
        /// ���U PlcLabel ��W�U��]�� PlcLabel ����I�s�^
        /// </summary>
        public static void Register(PlcLabel label)
        {
            if (label == null || string.IsNullOrWhiteSpace(label.Address))
                return;

            lock (_lock)
            {
                // �M�z�w�^�����z�ޥ�
                _registeredLabels.RemoveWhere(wr => !wr.TryGetTarget(out _));

                // �קK���Ƶ��U
                if (!_registeredLabels.Any(wr => wr.TryGetTarget(out var l) && ReferenceEquals(l, label)))
                {
                    _registeredLabels.Add(new WeakReference<PlcLabel>(label));
                    
                    #if DEBUG
                    System.Diagnostics.Debug.WriteLine($"[PlcLabelContext] Registered: {label.Address}");
                    #endif
                }
            }
        }

        /// <summary>
        /// ���P PlcLabel�]�� PlcLabel ����I�s�^
        /// </summary>
        public static void Unregister(PlcLabel label)
        {
            if (label == null)
                return;

            lock (_lock)
            {
                _registeredLabels.RemoveWhere(wr => 
                {
                    if (wr.TryGetTarget(out var l))
                        return ReferenceEquals(l, label);
                    return true; // �M�z�w�^�����ޥ�
                });

                #if DEBUG
                System.Diagnostics.Debug.WriteLine($"[PlcLabelContext] Unregistered: {label.Address}");
                #endif
            }
        }

        /// <summary>
        /// ?? �q�w���U�� PlcLabel �����z�����ʱ���}
        /// �۰ʦX�ֳs���}�]�Ҧp D90, D91, D92 �� D90,3�^
        /// </summary>
        /// <returns>�ʱ���}�r��]�Ҧp "D90,3,M100,1,X10,1"�^</returns>
        public static string GenerateMonitorAddresses()
        {
            lock (_lock)
            {
                // �M�z�w�^�����z�ޥ�
                _registeredLabels.RemoveWhere(wr => !wr.TryGetTarget(out _));

                var addresses = new List<string>();
                foreach (var weakRef in _registeredLabels)
                {
                    if (weakRef.TryGetTarget(out var label) && !string.IsNullOrWhiteSpace(label.Address))
                    {
                        addresses.Add(label.Address.Trim().ToUpper());
                    }
                }

                if (addresses.Count == 0)
                    return string.Empty;

                return GenerateOptimizedAddresses(addresses);
            }
        }

        #endregion

        #region ���}��k

        /// <summary>
        /// �q�� PlcLabel �Ȥw�ܧ�]�� PlcLabel ��������I�s�^
        /// </summary>
        /// <param name="label">Ĳ�o�� PlcLabel</param>
        /// <param name="value">�s����</param>
        public static void NotifyValueChanged(PlcLabel label, object value)
        {
            if (label == null || value == null)
                return;

            // ?? �b UI ������WĲ�o�ƥ�]�T�O������w���A���� SensorContext�^
            Application.Current?.Dispatcher.BeginInvoke(() =>
            {
                ValueChanged?.Invoke(null, new PlcLabelValueChangedEventArgs(label, value));
            });

            // �O����x�]�i��A�Ω󰣿��^
            LogValueChange(label, value);
        }

        #endregion

        #region �p����k

        /// <summary>
        /// ���z�X�ֳs���}�]���� SensorContext�^
        /// </summary>
        private static string GenerateOptimizedAddresses(List<string> addresses)
        {
            var addressGroups = new Dictionary<string, List<int>>();

            // 1. �ѪR�ä��զ�}
            foreach (var address in addresses)
            {
                if (System.Text.RegularExpressions.Regex.Match(address, @"^([A-Z]+)(\d+)$") is var match && match.Success)
                {
                    string deviceType = match.Groups[1].Value; // D, M, X, Y, R
                    int deviceNumber = int.Parse(match.Groups[2].Value);

                    if (!addressGroups.ContainsKey(deviceType))
                    {
                        addressGroups[deviceType] = new List<int>();
                    }

                    if (!addressGroups[deviceType].Contains(deviceNumber))
                    {
                        addressGroups[deviceType].Add(deviceNumber);
                    }
                }
            }

            // 2. ���z�X�ֳs���}
            var monitorParts = new List<string>();

            foreach (var group in addressGroups.OrderBy(g => g.Key))
            {
                string deviceType = group.Key;
                var numbers = group.Value.OrderBy(n => n).ToList();

                int i = 0;
                while (i < numbers.Count)
                {
                    int start = numbers[i];
                    int end = start;

                    // ��X�s��d��
                    while (i + 1 < numbers.Count && numbers[i + 1] == end + 1)
                    {
                        i++;
                        end = numbers[i];
                    }

                    int length = end - start + 1;

                    // �s�� 2 �ӥH�W�N�妸�X��
                    if (length >= 2)
                    {
                        monitorParts.Add($"{deviceType}{start},{length}");
                    }
                    else
                    {
                        monitorParts.Add($"{deviceType}{start},1");
                    }

                    i++;
                }
            }

            return string.Join(",", monitorParts);
        }

        /// <summary>
        /// �O�����ܧ��x�]�Ω󰣿��^
        /// </summary>
        private static void LogValueChange(PlcLabel label, object value)
        {
            // �u�b�ݭn�ɰO���]�קK�L�h��x�^
            #if DEBUG
            System.Diagnostics.Debug.WriteLine(
                $"[PlcLabelContext] {label.Label} ({label.Address}) = {value}"
            );
            #endif
        }

        #endregion
    }

    #region �ƥ�Ѽ�

    /// <summary>
    /// PlcLabel ���ܧ�ƥ�Ѽ�
    /// </summary>
    public class PlcLabelValueChangedEventArgs : EventArgs
    {
        /// <summary>
        /// Ĳ�o�ƥ� PlcLabel
        /// </summary>
        public PlcLabel PlcLabel { get; }

        /// <summary>
        /// �s���ȡ]��l�ȡ^
        /// </summary>
        public object Value { get; }

        /// <summary>
        /// �ƥ�o�ͮɶ�
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// PlcLabel ����}�]�ֳt�s���^
        /// </summary>
        public string Address => PlcLabel.Address;

        /// <summary>
        /// PlcLabel �����Ҥ�r�]�ֳt�s���^
        /// </summary>
        public string Label => PlcLabel.Label;

        public PlcLabelValueChangedEventArgs(PlcLabel label, object value)
        {
            PlcLabel = label ?? throw new ArgumentNullException(nameof(label));
            Value = value ?? throw new ArgumentNullException(nameof(value));
            Timestamp = DateTime.Now;
        }
    }

    #endregion
}
