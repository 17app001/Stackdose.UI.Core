namespace Stackdose.UI.Core.Models
{
    /// <summary>
    /// �ϥΪ̱b�� (User Account)
    /// </summary>
    public class UserAccount
    {
        /// <summary>
        /// �ߤ@�ѧO�X (Unique ID)
        /// </summary>
        public string UserId { get; set; } = string.Empty;

        /// <summary>
        /// ��ܦW�� (Display Name)
        /// </summary>
        public string DisplayName { get; set; } = string.Empty;

        /// <summary>
        /// �K�X���� (SHA-256)
        /// </summary>
        public string PasswordHash { get; set; } = string.Empty;

        /// <summary>
        /// �v������
        /// </summary>
        public AccessLevel AccessLevel { get; set; } = AccessLevel.Operator;

        /// <summary>
        /// �b���O�_�ҥ�
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// �إ߮ɶ�
        /// </summary>
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        /// <summary>
        /// �̫�n�J�ɶ�
        /// </summary>
        public DateTime? LastLoginAt { get; set; }

        /// <summary>
        /// �إߪ� (Audit Trail)
        /// </summary>
        public string CreatedBy { get; set; } = "System";

        /// <summary>
        /// �Ƶ�
        /// </summary>
        public string? Remarks { get; set; }
    }
}
