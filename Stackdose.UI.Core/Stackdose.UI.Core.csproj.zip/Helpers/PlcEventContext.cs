using System;
using System.Windows;
using Stackdose.UI.Core.Controls;
using System.Collections.Generic;
using System.Linq;

namespace Stackdose.UI.Core.Helpers
{
    /// <summary>
    /// PlcEventTrigger �W�U��޲z (PlcEvent Context Manager)
    /// �γ~�G�Τ@�޲z�Ҧ� PlcEventTrigger ��Ĳ�o�ƥ�
    /// ���� SensorContext ���]�p�A�Ω�B�z PLC �ƥ�Ĳ�o�]�p M237, M238�^
    /// </summary>
    public static class PlcEventContext
    {
        #region �R�A�ݩ�

        /// <summary>
        /// �w���U�� PlcEventTrigger �M��]�Ω�۰ʺʱ��^
        /// </summary>
        private static readonly HashSet<WeakReference<PlcEventTrigger>> _registeredTriggers = new HashSet<WeakReference<PlcEventTrigger>>();
        private static readonly object _lock = new object();

        #endregion

        #region �ƥ�w�q

        /// <summary>
        /// �ƥ�Ĳ�o�ƥ� (�� PlcEventTrigger ��������󺡨���Ĳ�o)
        /// </summary>
        public static event EventHandler<PlcEventTriggeredEventArgs>? EventTriggered;

        #endregion

        #region ���U�޲z

        /// <summary>
        /// ���U PlcEventTrigger ��W�U��]�� PlcEventTrigger ����I�s�^
        /// </summary>
        public static void Register(PlcEventTrigger trigger)
        {
            if (trigger == null || string.IsNullOrWhiteSpace(trigger.Address))
                return;

            lock (_lock)
            {
                // �M�z�w�^�����z�ޥ�
                _registeredTriggers.RemoveWhere(wr => !wr.TryGetTarget(out _));

                // �קK���Ƶ��U
                if (!_registeredTriggers.Any(wr => wr.TryGetTarget(out var t) && ReferenceEquals(t, trigger)))
                {
                    _registeredTriggers.Add(new WeakReference<PlcEventTrigger>(trigger));
                    
                    #if DEBUG
                    System.Diagnostics.Debug.WriteLine($"[PlcEventContext] Registered: {trigger.EventName} ({trigger.Address})");
                    #endif
                }
            }
        }

        /// <summary>
        /// ���P PlcEventTrigger�]�� PlcEventTrigger ����I�s�^
        /// </summary>
        public static void Unregister(PlcEventTrigger trigger)
        {
            if (trigger == null)
                return;

            lock (_lock)
            {
                _registeredTriggers.RemoveWhere(wr => 
                {
                    if (wr.TryGetTarget(out var t))
                        return ReferenceEquals(t, trigger);
                    return true; // �M�z�w�^�����ޥ�
                });

                #if DEBUG
                System.Diagnostics.Debug.WriteLine($"[PlcEventContext] Unregistered: {trigger.EventName} ({trigger.Address})");
                #endif
            }
        }

        /// <summary>
        /// ?? �q�w���U�� PlcEventTrigger �����z�����ʱ���}
        /// �۰ʦX�ֳs���}�]�Ҧp M237, M238, M239 �� M237,3�^
        /// </summary>
        /// <returns>�ʱ���}�r��]�Ҧp "M237,3,M400,1"�^</returns>
        public static string GenerateMonitorAddresses()
        {
            lock (_lock)
            {
                // �M�z�w�^�����z�ޥ�
                _registeredTriggers.RemoveWhere(wr => !wr.TryGetTarget(out _));

                var addresses = new List<string>();
                foreach (var weakRef in _registeredTriggers)
                {
                    if (weakRef.TryGetTarget(out var trigger) && !string.IsNullOrWhiteSpace(trigger.Address))
                    {
                        addresses.Add(trigger.Address.Trim().ToUpper());
                    }
                }

                if (addresses.Count == 0)
                    return string.Empty;

                return GenerateOptimizedAddresses(addresses);
            }
        }

        #endregion

        #region ���}��k

        /// <summary>
        /// �q���ƥ�wĲ�o�]�� PlcEventTrigger ��������I�s�^
        /// ?? �ϥΦP�B Invoke�A�T�O�ƥ�B�z������~��^
        /// </summary>
        /// <param name="trigger">Ĳ�o�� PlcEventTrigger</param>
        /// <param name="value">Ĳ�o�ɪ���</param>
        public static void NotifyEventTriggered(PlcEventTrigger trigger, object value)
        {
            if (trigger == null)
                return;

            // ?? ��ΦP�B Invoke�]���뵥�ݡ^�A�T�O�ƥ�B�z����
            Application.Current?.Dispatcher.Invoke(() =>
            {
                EventTriggered?.Invoke(null, new PlcEventTriggeredEventArgs(trigger, value));
            });

            // �O����x
            LogEventTrigger(trigger, value);
        }

        #endregion

        #region �p����k

        /// <summary>
        /// ���z�X�ֳs���}�]���� PlcLabelContext�^
        /// </summary>
        private static string GenerateOptimizedAddresses(List<string> addresses)
        {
            var addressGroups = new Dictionary<string, List<int>>();

            // 1. �ѪR�ä��զ�}
            foreach (var address in addresses)
            {
                if (System.Text.RegularExpressions.Regex.Match(address, @"^([A-Z]+)(\d+)$") is var match && match.Success)
                {
                    string deviceType = match.Groups[1].Value; // D, M, X, Y, R
                    int deviceNumber = int.Parse(match.Groups[2].Value);

                    if (!addressGroups.ContainsKey(deviceType))
                    {
                        addressGroups[deviceType] = new List<int>();
                    }

                    if (!addressGroups[deviceType].Contains(deviceNumber))
                    {
                        addressGroups[deviceType].Add(deviceNumber);
                    }
                }
            }

            // 2. ���z�X�ֳs���}
            var monitorParts = new List<string>();

            foreach (var group in addressGroups.OrderBy(g => g.Key))
            {
                string deviceType = group.Key;
                var numbers = group.Value.OrderBy(n => n).ToList();

                int i = 0;
                while (i < numbers.Count)
                {
                    int start = numbers[i];
                    int end = start;

                    // ��X�s��d��
                    while (i + 1 < numbers.Count && numbers[i + 1] == end + 1)
                    {
                        i++;
                        end = numbers[i];
                    }

                    int length = end - start + 1;

                    // �s�� 2 �ӥH�W�N�妸�X��
                    if (length >= 2)
                    {
                        monitorParts.Add($"{deviceType}{start},{length}");
                    }
                    else
                    {
                        monitorParts.Add($"{deviceType}{start},1");
                    }

                    i++;
                }
            }

            return string.Join(",", monitorParts);
        }

        /// <summary>
        /// �O���ƥ�Ĳ�o��x
        /// </summary>
        private static void LogEventTrigger(PlcEventTrigger trigger, object value)
        {
            ComplianceContext.LogSystem(
                $"[PlcEvent] {trigger.EventName} ({trigger.Address}) = {value}",
                Models.LogLevel.Info,
                showInUi: false
            );
        }

        #endregion
    }

    #region �ƥ�Ѽ�

    /// <summary>
    /// PlcEvent Ĳ�o�ƥ�Ѽ�
    /// </summary>
    public class PlcEventTriggeredEventArgs : EventArgs
    {
        /// <summary>
        /// Ĳ�o�ƥ� PlcEventTrigger
        /// </summary>
        public PlcEventTrigger Trigger { get; }

        /// <summary>
        /// Ĳ�o�ɪ���
        /// </summary>
        public object Value { get; }

        /// <summary>
        /// �ƥ�o�ͮɶ�
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// PLC ��}�]�ֳt�s���^
        /// </summary>
        public string Address => Trigger.Address;

        /// <summary>
        /// �ƥ�W�١]�ֳt�s���^
        /// </summary>
        public string EventName => Trigger.EventName;

        public PlcEventTriggeredEventArgs(PlcEventTrigger trigger, object value)
        {
            Trigger = trigger ?? throw new ArgumentNullException(nameof(trigger));
            Value = value ?? throw new ArgumentNullException(nameof(value));
            Timestamp = DateTime.Now;
        }
    }

    #endregion
}
