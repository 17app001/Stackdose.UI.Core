using Stackdose.UI.Core.Models;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace Stackdose.UI.Core.Helpers
{
    /// <summary>
    /// �w���ʤW�U��޲z (Security Context Manager)
    /// �γ~�G�Τ@�޲z�ϥΪ̵n�J�B�v������B�۰ʵn�X
    /// �ŦX FDA 21 CFR Part 11 �n�D
    /// </summary>
    public static class SecurityContext
    {
        #region �R�A�ݩ�

        /// <summary>
        /// ���e�ϥΪ̤u�@���q
        /// </summary>
        public static UserSession CurrentSession { get; } = new UserSession();

        /// <summary>
        /// �۰ʵn�X�ɶ��]�����A�w�] 15�^
        /// </summary>
        public static int AutoLogoutMinutes { get; set; } = 15;

        /// <summary>
        /// �O�_�ҥΦ۰ʵn�X�\��
        /// </summary>
        public static bool EnableAutoLogout { get; set; } = true;

        #endregion

        #region �ƥ�w�q

        /// <summary>
        /// �n�J���\�ƥ�
        /// </summary>
        public static event EventHandler<UserAccount>? LoginSuccess;

        /// <summary>
        /// �n�X�ƥ�
        /// </summary>
        public static event EventHandler? LogoutOccurred;

        /// <summary>
        /// �v���ܧ�ƥ� (�Ω��s UI)
        /// </summary>
        public static event EventHandler? AccessLevelChanged;

        #endregion

        #region �n�J/�n�X

        /// <summary>
        /// �ϥΪ̵n�J
        /// </summary>
        /// <param name="userId">�ϥΪ̱b��</param>
        /// <param name="password">�K�X</param>
        /// <returns>�O�_�n�J���\</returns>
        public static bool Login(string userId, string password)
        {
            // 1. �q��Ʈw�d�ߨϥΪ�
            var user = LoadUserFromDatabase(userId);
            if (user == null || !user.IsActive)
            {
                ComplianceContext.LogSystem(
                    $"Login Failed: User '{userId}' not found or inactive",
                    LogLevel.Warning,
                    showInUi: true
                );
                return false;
            }

            // 2. ���ұK�X
            string passwordHash = HashPassword(password);
            if (user.PasswordHash != passwordHash)
            {
                ComplianceContext.LogSystem(
                    $"Login Failed: Invalid password for user '{userId}'",
                    LogLevel.Warning,
                    showInUi: true
                );
                
                // ?? Audit Trail�G�n�J����
                ComplianceContext.LogAuditTrail(
                    "User Login",
                    userId,
                    "N/A",
                    "Failed",
                    "Invalid password",
                    showInUi: false
                );
                return false;
            }

            // 3. �n�J���\
            CurrentSession.CurrentUser = user;
            CurrentSession.LoginTime = DateTime.Now;
            CurrentSession.LastActivityTime = DateTime.Now;
            user.LastLoginAt = DateTime.Now;

            // 4. �O���� Audit Trail
            ComplianceContext.LogAuditTrail(
                "User Login",
                userId,
                "Logged Out",
                $"Logged In (Level {(int)user.AccessLevel} - {user.AccessLevel})",
                $"Login from {Environment.MachineName}",
                showInUi: true
            );

            ComplianceContext.LogSystem(
                $"? Login Success: {user.DisplayName} ({user.AccessLevel})",
                LogLevel.Success,
                showInUi: true
            );

            // 5. Ĳ�o�ƥ�
            LoginSuccess?.Invoke(null, user);
            AccessLevelChanged?.Invoke(null, EventArgs.Empty);

            // 6. �Ұʦ۰ʵn�X�p�ɾ�
            if (EnableAutoLogout)
            {
                StartAutoLogoutTimer();
            }

            return true;
        }

        /// <summary>
        /// ?? �ֳt�n�J�]�w�]�b���A�Ω���թΪ�l�ơ^
        /// </summary>
        /// <param name="level">�v������</param>
        public static void QuickLogin(AccessLevel level = AccessLevel.Engineer)
        {
            var user = new UserAccount
            {
                UserId = level.ToString().ToLower(),
                DisplayName = GetLevelDisplayName(level),
                PasswordHash = HashPassword("1234"),
                AccessLevel = level,
                IsActive = true,
                CreatedBy = "System",
                CreatedAt = DateTime.Now
            };

            CurrentSession.CurrentUser = user;
            CurrentSession.LoginTime = DateTime.Now;
            CurrentSession.LastActivityTime = DateTime.Now;

            ComplianceContext.LogSystem(
                $"?? Quick Login: {user.DisplayName} ({user.AccessLevel})",
                LogLevel.Info,
                showInUi: true
            );

            // Ĳ�o�ƥ�
            LoginSuccess?.Invoke(null, user);
            AccessLevelChanged?.Invoke(null, EventArgs.Empty);

            // �Ұʦ۰ʵn�X�p�ɾ�
            if (EnableAutoLogout)
            {
                StartAutoLogoutTimer();
            }
        }

        /// <summary>
        /// �ϥΪ̵n�X
        /// </summary>
        /// <param name="isAutoLogout">�O�_���۰ʵn�X</param>
        public static void Logout(bool isAutoLogout = false)
        {
            if (!CurrentSession.IsLoggedIn)
                return;

            var user = CurrentSession.CurrentUser!;

            // 1. �O���� Audit Trail
            string reason = isAutoLogout ? "Auto-Logout (Timeout)" : "Manual Logout";
            ComplianceContext.LogAuditTrail(
                "User Logout",
                user.UserId,
                $"Logged In (Level {(int)user.AccessLevel} - {user.AccessLevel})",
                "Logged Out",
                reason,
                showInUi: true
            );

            ComplianceContext.LogSystem(
                $"?? Logout: {user.DisplayName} ({reason})",
                LogLevel.Warning,
                showInUi: true
            );

            // 2. �M���u�@���q
            CurrentSession.CurrentUser = null;

            // 3. Ĳ�o�ƥ�
            LogoutOccurred?.Invoke(null, EventArgs.Empty);
            AccessLevelChanged?.Invoke(null, EventArgs.Empty);

            // 4. ����۰ʵn�X�p�ɾ�
            StopAutoLogoutTimer();
        }

        /// <summary>
        /// ��s�̫ᬡ�ʮɶ��]�� UI �ާ@�ɩI�s�^
        /// </summary>
        public static void UpdateActivity()
        {
            if (CurrentSession.IsLoggedIn)
            {
                CurrentSession.LastActivityTime = DateTime.Now;
            }
        }

        #endregion

        #region �v���ˬd

        /// <summary>
        /// �ˬd���e�ϥΪ̬O�_�����w�v��
        /// </summary>
        /// <param name="requiredLevel">�һ��v������</param>
        /// <returns>�O�_���v��</returns>
        public static bool HasAccess(AccessLevel requiredLevel)
        {
            return CurrentSession.HasAccess(requiredLevel);
        }

        /// <summary>
        /// �ˬd�v���A�p�G�����h��ܰT���ê�^ false
        /// </summary>
        /// <param name="requiredLevel">�һ��v������</param>
        /// <param name="operationName">�ާ@�W��</param>
        /// <returns>�O�_���v��</returns>
        public static bool CheckAccess(AccessLevel requiredLevel, string operationName = "���ާ@")
        {
            if (HasAccess(requiredLevel))
                return true;

            string message = $"? �v������\n\n{operationName} �ݭn {GetLevelDisplayName(requiredLevel)} �H�W�v��\n\n���e�v��: {GetLevelDisplayName(CurrentSession.CurrentLevel)}";
            
            ComplianceContext.LogSystem(
                $"Access Denied: {operationName} requires {requiredLevel} (Current: {CurrentSession.CurrentLevel})",
                LogLevel.Warning,
                showInUi: true
            );

            // �O���� Audit Trail
            ComplianceContext.LogAuditTrail(
                "Access Denied",
                CurrentSession.CurrentUser?.UserId ?? "Guest",
                operationName,
                "Denied",
                $"Required Level: {requiredLevel}",
                showInUi: false
            );

            Application.Current?.Dispatcher.BeginInvoke(() =>
            {
                MessageBox.Show(message, "�v������ - Access Denied", MessageBoxButton.OK, MessageBoxImage.Warning);
            });

            return false;
        }

        #endregion

        #region �۰ʵn�X�p�ɾ�

        private static System.Threading.Timer? _autoLogoutTimer;

        private static void StartAutoLogoutTimer()
        {
            StopAutoLogoutTimer();

            _autoLogoutTimer = new System.Threading.Timer(_ =>
            {
                if (!CurrentSession.IsLoggedIn || !EnableAutoLogout)
                    return;

                var idleTime = DateTime.Now - CurrentSession.LastActivityTime;
                if (idleTime.TotalMinutes >= AutoLogoutMinutes)
                {
                    Application.Current?.Dispatcher.Invoke(() => Logout(isAutoLogout: true));
                }
            }, null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30)); // �C 30 ���ˬd�@��
        }

        private static void StopAutoLogoutTimer()
        {
            _autoLogoutTimer?.Dispose();
            _autoLogoutTimer = null;
        }

        #endregion

        #region �K�X�[�K

        /// <summary>
        /// SHA-256 �K�X����
        /// </summary>
        /// <param name="password">����K�X</param>
        /// <returns>����᪺�K�X</returns>
        public static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        #endregion

        #region ��Ʈw�s�� (Placeholder)

        /// <summary>
        /// �q��Ʈw���J�ϥΪ̡]�Ȯɨϥιw�]�b���^
        /// </summary>
        private static UserAccount? LoadUserFromDatabase(string userId)
        {
            // ?? TODO: �q SQLite Ū��
            // �Ȯɦ^�ǹw�]���ձb��
            var defaultAccounts = new Dictionary<string, UserAccount>
            {
                ["admin"] = new UserAccount
                {
                    UserId = "admin",
                    DisplayName = "�t�κ޲z��",
                    PasswordHash = HashPassword("1234"),
                    AccessLevel = AccessLevel.Engineer,
                    IsActive = true,
                    CreatedBy = "System"
                },
                ["engineer"] = new UserAccount
                {
                    UserId = "engineer",
                    DisplayName = "�u�{�v",
                    PasswordHash = HashPassword("1234"),
                    AccessLevel = AccessLevel.Engineer,
                    IsActive = true,
                    CreatedBy = "System"
                },
                ["supervisor"] = new UserAccount
                {
                    UserId = "supervisor",
                    DisplayName = "�D��",
                    PasswordHash = HashPassword("1234"),
                    AccessLevel = AccessLevel.Supervisor,
                    IsActive = true,
                    CreatedBy = "System"
                },
                ["instructor"] = new UserAccount
                {
                    UserId = "instructor",
                    DisplayName = "���ɭ�",
                    PasswordHash = HashPassword("1234"),
                    AccessLevel = AccessLevel.Instructor,
                    IsActive = true,
                    CreatedBy = "System"
                },
                ["operator"] = new UserAccount
                {
                    UserId = "operator",
                    DisplayName = "�ާ@��",
                    PasswordHash = HashPassword("1234"),
                    AccessLevel = AccessLevel.Operator,
                    IsActive = true,
                    CreatedBy = "System"
                }
            };

            return defaultAccounts.TryGetValue(userId.ToLower(), out var account) ? account : null;
        }

        #endregion

        #region ���U��k

        /// <summary>
        /// ���o�v�����Ū���ܦW��
        /// </summary>
        private static string GetLevelDisplayName(AccessLevel level)
        {
            return level switch
            {
                AccessLevel.Guest => "�X�� (Guest)",
                AccessLevel.Operator => "�ާ@�� (Operator)",
                AccessLevel.Instructor => "���ɭ� (Instructor)",
                AccessLevel.Supervisor => "�D�� (Supervisor)",
                AccessLevel.Engineer => "�u�{�v (Engineer)",
                _ => "����"
            };
        }

        #endregion
    }
}
