using Stackdose.UI.Core.Helpers;
using System.Windows;
using System.Windows.Input;

namespace Stackdose.UI.Core.Controls
{
    /// <summary>
    /// �ϥΪ̵n�J��ܮ�
    /// </summary>
    public partial class LoginDialog : Window
    {
        public bool LoginSuccessful { get; private set; } = false;

        public LoginDialog()
        {
            InitializeComponent();

            // �䴩 Enter ��n�J
            this.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    LoginButton_Click(null, null);
                }
                else if (e.Key == Key.Escape)
                {
                    CancelButton_Click(null, null);
                }
            };

            // �۰� focus ��b�����
            this.Loaded += (s, e) => UserIdTextBox.Focus();
        }

        private void LoginButton_Click(object? sender, RoutedEventArgs? e)
        {
            // �M�����~�T��
            ErrorText.Visibility = Visibility.Collapsed;

            // ���o��J
            string userId = UserIdTextBox.Text.Trim();
            string password = PasswordBox.Password;

            // ���ҿ�J
            if (string.IsNullOrWhiteSpace(userId))
            {
                ShowError("�п�J�b�� (Please enter User ID)");
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                ShowError("�п�J�K�X (Please enter Password)");
                return;
            }

            // ���յn�J
            bool success = SecurityContext.Login(userId, password);

            if (success)
            {
                LoginSuccessful = true;
                this.DialogResult = true;
                this.Close();
            }
            else
            {
                ShowError("�n�J���ѡG�b���αK�X���~\nLogin Failed: Invalid User ID or Password");
                PasswordBox.Clear();
                PasswordBox.Focus();
            }
        }

        private void CancelButton_Click(object? sender, RoutedEventArgs? e)
        {
            LoginSuccessful = false;
            this.DialogResult = false;
            this.Close();
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorText.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// ��ܵn�J��ܮ�
        /// </summary>
        /// <returns>�O�_�n�J���\</returns>
        public static bool ShowLoginDialog()
        {
            var dialog = new LoginDialog();
            bool? result = dialog.ShowDialog();
            return result == true && dialog.LoginSuccessful;
        }
    }
}
