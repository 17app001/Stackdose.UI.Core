using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Stackdose.UI.Core.Controls
{
    /// <summary>
    /// Cyber ���檺�ۭq MessageBox
    /// </summary>
    public partial class CyberMessageBox : Window
    {
        #region ���}�ݩ�

        /// <summary>
        /// �ϥΪ̿�ܪ����G
        /// </summary>
        public MessageBoxResult Result { get; private set; } = MessageBoxResult.None;

        #endregion

        #region �غc�l

        private CyberMessageBox(string message, string title, MessageBoxButton buttons, MessageBoxImage icon)
        {
            InitializeComponent();

            // �]�w���D
            TitleText.Text = title;
            Title = title;

            // �]�w�T��
            MessageText.Text = message;

            // �]�w�ϥ�
            SetIcon(icon);

            // �]�w���s
            SetButtons(buttons);

            // ���J�ʵe
            Loaded += (s, e) => PlayShowAnimation();
        }

        #endregion

        #region �R�A��k (�����з� MessageBox)

        /// <summary>
        /// ��ܰT���]�� OK ���s�^
        /// </summary>
        public static MessageBoxResult Show(string message)
        {
            return Show(message, "�T��", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// ��ܰT���]���w���D�^
        /// </summary>
        public static MessageBoxResult Show(string message, string title)
        {
            return Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// ��ܰT���]���w���s�^
        /// </summary>
        public static MessageBoxResult Show(string message, string title, MessageBoxButton buttons)
        {
            return Show(message, title, buttons, MessageBoxImage.Information);
        }

        /// <summary>
        /// ��ܰT���]����Ѽơ^
        /// </summary>
        public static MessageBoxResult Show(string message, string title, MessageBoxButton buttons, MessageBoxImage icon)
        {
            // ?? �ץ��G�T�O�b UI ������W����
            if (!Application.Current.Dispatcher.CheckAccess())
            {
                return Application.Current.Dispatcher.Invoke(() =>
                {
                    var messageBox = new CyberMessageBox(message, title, buttons, icon);
                    messageBox.ShowDialog();
                    return messageBox.Result;
                });
            }
            else
            {
                var messageBox = new CyberMessageBox(message, title, buttons, icon);
                messageBox.ShowDialog();
                return messageBox.Result;
            }
        }

        #endregion

        #region �p����k

        /// <summary>
        /// �]�w�ϥ�
        /// </summary>
        private void SetIcon(MessageBoxImage icon)
        {
            string emoji = "??";
            string color = "#00E5FF"; // �w�]�Ŧ�

            switch (icon)
            {
                case MessageBoxImage.Information:
                    emoji = "??";
                    color = "#00E5FF";
                    break;
                case MessageBoxImage.Warning:
                    emoji = "??";
                    color = "#FFA726";
                    break;
                case MessageBoxImage.Error:
                    emoji = "?";
                    color = "#FF5252";
                    break;
                case MessageBoxImage.Question:
                    emoji = "?";
                    color = "#AB47BC";
                    break;
                default:
                    emoji = "?";
                    color = "#4CAF50";
                    break;
            }

            TitleIcon.Text = emoji;
            MessageIcon.Text = emoji;

            // ��s����C��
            var border = (Border)Content;
            border.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));

            // ��s���D��r�C��
            TitleText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
        }

        /// <summary>
        /// �]�w���s
        /// </summary>
        private void SetButtons(MessageBoxButton buttons)
        {
            ButtonPanel.Children.Clear();

            switch (buttons)
            {
                case MessageBoxButton.OK:
                    AddButton("�T�w", MessageBoxResult.OK, true);
                    break;

                case MessageBoxButton.OKCancel:
                    AddButton("�T�w", MessageBoxResult.OK, true);
                    AddButton("����", MessageBoxResult.Cancel, false, true);
                    break;

                case MessageBoxButton.YesNo:
                    AddButton("�O", MessageBoxResult.Yes, true);
                    AddButton("�_", MessageBoxResult.No, false, true);
                    break;

                case MessageBoxButton.YesNoCancel:
                    AddButton("�O", MessageBoxResult.Yes, true);
                    AddButton("�_", MessageBoxResult.No, false);
                    AddButton("����", MessageBoxResult.Cancel, false, true);
                    break;
            }
        }

        /// <summary>
        /// �s�W���s
        /// </summary>
        private void AddButton(string text, MessageBoxResult result, bool isDefault, bool isCancel = false)
        {
            var button = new Button
            {
                Content = text,
                Margin = new Thickness(5, 0, 5, 0),
                Style = isCancel 
                    ? (Style)FindResource("CancelButtonStyle") 
                    : (Style)FindResource("CyberButtonStyle")
            };

            button.Click += (s, e) =>
            {
                Result = result;
                Close();
            };

            if (isDefault)
            {
                button.IsDefault = true;
            }

            if (isCancel)
            {
                button.IsCancel = true;
            }

            ButtonPanel.Children.Add(button);
        }

        /// <summary>
        /// �������s�I��
        /// </summary>
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Result = MessageBoxResult.Cancel;
            Close();
        }

        /// <summary>
        /// ������ܰʵe
        /// </summary>
        private void PlayShowAnimation()
        {
            // ?? �ץ��G�鷺�e�e���]Border�^�M�ΰʵe�A�ӫD Window ����
            var border = (Border)Content;

            // �H�J�ʵe�]�M�Ψ� Window�^
            var fadeIn = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(200)
            };

            // �Y��ʵe�]�M�Ψ� Border�^
            var scaleX = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 0.9,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(200),
                EasingFunction = new System.Windows.Media.Animation.BackEase
                {
                    Amplitude = 0.3,
                    EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut
                }
            };

            var scaleY = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 0.9,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(200),
                EasingFunction = new System.Windows.Media.Animation.BackEase
                {
                    Amplitude = 0.3,
                    EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut
                }
            };

            // ?? �ץ��G�N ScaleTransform �M�Ψ� Border�A�ӫD Window
            var scaleTransform = new ScaleTransform(0.9, 0.9);
            border.RenderTransformOrigin = new Point(0.5, 0.5);
            border.RenderTransform = scaleTransform;

            // Window �M�βH�J�ʵe
            BeginAnimation(OpacityProperty, fadeIn);

            // Border �M���Y��ʵe
            scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleX);
            scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleY);
        }

        #endregion
    }

    #region �X�R��k (���)

    /// <summary>
    /// CyberMessageBox �X�R��k
    /// </summary>
    public static class CyberMessageBoxExtensions
    {
        /// <summary>
        /// ��ܦ��\�T��
        /// </summary>
        public static void ShowSuccess(string message, string title = "���\")
        {
            CyberMessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.None);
        }

        /// <summary>
        /// ���ĵ�i�T��
        /// </summary>
        public static void ShowWarning(string message, string title = "ĵ�i")
        {
            CyberMessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        /// <summary>
        /// ��ܿ��~�T��
        /// </summary>
        public static void ShowError(string message, string title = "���~")
        {
            CyberMessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error);
        }

        /// <summary>
        /// ��ܽT�{��ܮ�
        /// </summary>
        public static bool Confirm(string message, string title = "�T�{")
        {
            var result = CyberMessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question);
            return result == MessageBoxResult.Yes;
        }
    }

    #endregion
}
