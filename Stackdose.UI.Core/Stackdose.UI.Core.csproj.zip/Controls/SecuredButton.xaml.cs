using Stackdose.UI.Core.Helpers;
using Stackdose.UI.Core.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Stackdose.UI.Core.Controls
{
    /// <summary>
    /// Secured Button with Permission Control and Theme Support
    /// </summary>
    public partial class SecuredButton : UserControl
    {
        public SecuredButton()
        {
            InitializeComponent();
            
            // ?? �ˬd�O�_�b�]�p�Ҧ�
            bool isDesignMode = System.ComponentModel.DesignerProperties.GetIsInDesignMode(this);
            
            if (!isDesignMode)
            {
                // ����ɡG�q�\�v���ܧ�ƥ�
                SecurityContext.AccessLevelChanged += OnAccessLevelChanged;
                
                // ��l���v�����A
                UpdateAuthorization();
                
                // ����������ɨ����q�\
                this.Unloaded += (s, e) => SecurityContext.AccessLevelChanged -= OnAccessLevelChanged;
            }
            else
            {
                // �]�p�ɡG�j��]�w���w���v�]���Ҧ����s���i���^
                IsAuthorized = true;
            }
            
            // ?? �L�׳]�p�ɩΰ���ɡA���n��l�ƥD�D�C��
            UpdateThemeColors();
            
            // ?? �q�\ Loaded �ƥ�A�T�O�b XAML �ݩʳ]�w��A����s
            this.Loaded += (s, e) => UpdateThemeColors();
        }

        #region Dependency Properties

        /// <summary>
        /// ���s���e
        /// </summary>
        public static readonly DependencyProperty ContentProperty =
            DependencyProperty.Register("Content", typeof(object), typeof(SecuredButton), 
                new PropertyMetadata("Button"));
        
        public object Content
        {
            get => GetValue(ContentProperty);
            set => SetValue(ContentProperty, value);
        }

        /// <summary>
        /// �һ��v������
        /// </summary>
        public static readonly DependencyProperty RequiredLevelProperty =
            DependencyProperty.Register("RequiredLevel", typeof(AccessLevel), typeof(SecuredButton),
                new PropertyMetadata(AccessLevel.Operator, OnRequiredLevelChanged));

        public AccessLevel RequiredLevel
        {
            get => (AccessLevel)GetValue(RequiredLevelProperty);
            set => SetValue(RequiredLevelProperty, value);
        }

        /// <summary>
        /// �O�_�w���v�]�۰ʭp��^
        /// </summary>
        public static readonly DependencyProperty IsAuthorizedProperty =
            DependencyProperty.Register("IsAuthorized", typeof(bool), typeof(SecuredButton), 
                new PropertyMetadata(false));

        public bool IsAuthorized
        {
            get => (bool)GetValue(IsAuthorizedProperty);
            private set => SetValue(IsAuthorizedProperty, value);
        }

        /// <summary>
        /// ���s�C��D�D
        /// </summary>
        public static readonly DependencyProperty ThemeProperty =
            DependencyProperty.Register("Theme", typeof(ButtonTheme), typeof(SecuredButton),
                new PropertyMetadata(ButtonTheme.Normal, OnThemeChanged));

        public ButtonTheme Theme
        {
            get => (ButtonTheme)GetValue(ThemeProperty);
            set => SetValue(ThemeProperty, value);
        }

        /// <summary>
        /// �u�㴣�ܤ�r�]�۰ʥͦ��^
        /// </summary>
        public static readonly DependencyProperty TooltipTextProperty =
            DependencyProperty.Register("TooltipText", typeof(string), typeof(SecuredButton), 
                new PropertyMetadata(string.Empty));

        public string TooltipText
        {
            get => (string)GetValue(TooltipTextProperty);
            private set => SetValue(TooltipTextProperty, value);
        }

        /// <summary>
        /// �ާ@�W�١]�Ω��x�O���^
        /// </summary>
        public static readonly DependencyProperty OperationNameProperty =
            DependencyProperty.Register("OperationName", typeof(string), typeof(SecuredButton), 
                new PropertyMetadata(string.Empty));

        public string OperationName
        {
            get => (string)GetValue(OperationNameProperty);
            set => SetValue(OperationNameProperty, value);
        }

        /// <summary>
        /// �I���e��]���D�D�^
        /// </summary>
        public static readonly DependencyProperty BackgroundBrushProperty =
            DependencyProperty.Register("BackgroundBrush", typeof(Brush), typeof(SecuredButton), 
                new FrameworkPropertyMetadata(
                    new SolidColorBrush(Color.FromRgb(0x60, 0x7D, 0x8B)), 
                    FrameworkPropertyMetadataOptions.AffectsRender,
                    OnBackgroundBrushChanged));

        public Brush BackgroundBrush
        {
            get => (Brush)GetValue(BackgroundBrushProperty);
            set => SetValue(BackgroundBrushProperty, value);
        }

        private static void OnBackgroundBrushChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            #if DEBUG
            if (d is SecuredButton button)
            {
                System.Diagnostics.Debug.WriteLine($"[SecuredButton] BackgroundBrush Changed: {e.NewValue}");
            }
            #endif
        }

        /// <summary>
        /// �ƹ��a���e��]���D�D�^
        /// </summary>
        public static readonly DependencyProperty HoverBrushProperty =
            DependencyProperty.Register("HoverBrush", typeof(Brush), typeof(SecuredButton), 
                new FrameworkPropertyMetadata(
                    new SolidColorBrush(Color.FromRgb(0x45, 0x5A, 0x64)),
                    FrameworkPropertyMetadataOptions.AffectsRender));

        public Brush HoverBrush
        {
            get => (Brush)GetValue(HoverBrushProperty);
            set => SetValue(HoverBrushProperty, value);
        }

        #endregion

        #region �ƥ�

        /// <summary>
        /// �I���ƥ�]�u���b���v���ɤ~�|Ĳ�o�^
        /// </summary>
        public event RoutedEventHandler? Click;

        private void InnerButton_Click(object sender, RoutedEventArgs e)
        {
            // ��s���ʮɶ��]����۰ʵn�X�^
            SecurityContext.UpdateActivity();

            // �A���ˬd�v���]�����O�I�^
            if (!SecurityContext.HasAccess(RequiredLevel))
            {
                string opName = !string.IsNullOrEmpty(OperationName) ? OperationName : Content?.ToString() ?? "���ާ@";
                SecurityContext.CheckAccess(RequiredLevel, opName);
                return;
            }

            // Ĳ�o�~�� Click �ƥ�
            Click?.Invoke(this, e);
        }

        #endregion

        #region �v���P�D�D��s

        /// <summary>
        /// ���v�������ܧ��Ĳ�o
        /// </summary>
        private void OnAccessLevelChanged(object? sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(UpdateAuthorization);
        }

        /// <summary>
        /// ���һ��v�������ܧ��Ĳ�o
        /// </summary>
        private static void OnRequiredLevelChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is SecuredButton button)
                button.UpdateAuthorization();
        }

        /// <summary>
        /// ���D�D�ܧ��Ĳ�o
        /// </summary>
        private static void OnThemeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is SecuredButton button)
            {
                // ?? �ߧY��s�C��]�]�p�ɤ]�|����^
                button.UpdateThemeColors();
            }
        }

        /// <summary>
        /// ��s���v���A
        /// </summary>
        private void UpdateAuthorization()
        {
            bool hasAccess = SecurityContext.HasAccess(RequiredLevel);
            IsAuthorized = hasAccess;

            // ��s�u�㴣��
            if (hasAccess)
            {
                TooltipText = $"�v������: {RequiredLevel} ?";
            }
            else
            {
                string currentLevel = SecurityContext.CurrentSession.CurrentLevel.ToString();
                TooltipText = $"�ݭn�v��: {RequiredLevel}\n���e�v��: {currentLevel} ?";
            }
        }

        /// <summary>
        /// ��s�D�D�C��
        /// </summary>
        private void UpdateThemeColors()
        {
            try
            {
                var (background, hover) = Theme switch
                {
                    ButtonTheme.Normal => ("#607D8B", "#455A64"),      // Blue Grey
                    ButtonTheme.Primary => ("#2196F3", "#1976D2"),     // Blue
                    ButtonTheme.Success => ("#4CAF50", "#388E3C"),     // Green
                    ButtonTheme.Warning => ("#FF9800", "#F57C00"),     // Orange
                    ButtonTheme.Error => ("#F44336", "#D32F2F"),       // Red
                    ButtonTheme.Info => ("#00BCD4", "#0097A7"),        // Cyan
                    _ => ("#607D8B", "#455A64")
                };

                #if DEBUG
                System.Diagnostics.Debug.WriteLine($"[SecuredButton] UpdateThemeColors: Theme={Theme}, Background={background}");
                #endif

                // ?? �ϥ� SetValue �Ӥ��O�ݩ� setter�]��A�X DependencyProperty�^
                SetValue(BackgroundBrushProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString(background)));
                SetValue(HoverBrushProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString(hover)));
            }
            catch (Exception ex)
            {
                #if DEBUG
                System.Diagnostics.Debug.WriteLine($"[SecuredButton] UpdateThemeColors Error: {ex.Message}");
                #endif
            }
        }

        #endregion
    }
}
